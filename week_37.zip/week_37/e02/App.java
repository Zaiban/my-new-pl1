public class App {
    public static void main(final String[] args) {
        // YOUR CODE GOES HERE 
        int age = 34;
        double temperature = 22.3D;
        char initial = 'e';

        System.out.println(age);
        System.out.println(temperature);
        System.out.println(initial);
    }
}