public class App {
    public static void main(final String[] args) {
        // YOUR CODE GOES HERE 
        int num = 18;
        double decimal = 6.8;
        
        double result = num + decimal;

        System.out.println("result: " + result);

        int i = (int) result;

        System.out.println("new result: " + i);
    }
}