public class App {
    public static void main(final String[] args) {
        // YOUR CODE GOES HERE 
        int a = 35;
        int b = 18;

        System.out.println("a + b: " + (a+b));
        System.out.println("a - b: " + (a-b));
        System.out.println("a * b: " + (a*b));
        System.out.println("a / b: " + (a/b));
        System.out.println("a % b: " + (a%b));
    }
}